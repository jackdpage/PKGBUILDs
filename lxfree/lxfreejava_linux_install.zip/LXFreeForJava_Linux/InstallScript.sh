#! /bin/bash

java -version

################### make directory and move files

if [ ! -d /usr/share/claudeheintzdesign-lxseries ]
then
sudo mkdir /usr/share/claudeheintzdesign-lxseries
fi

sudo chmod 755 LXFreeForJava.jar

sudo mv LXFreeForJava.jar /usr/share/claudeheintzdesign-lxseries/
sudo mv LXicon.png /usr/share/claudeheintzdesign-lxseries/
sudo cp claudeheintzdesign-lxfreeforjava.desktop ~/Desktop/
sudo mv claudeheintzdesign-lxfreeforjava.desktop /usr/share/applications/

################### symbolic link to jar

if [ -f /usr/local/bin/lxfree4java ]
then
sudo rm -fr /usr/local/bin/lxfree4java
fi

sudo ln -s /usr/share/claudeheintzdesign-lxseries/LXFreeForJava.jar /usr/local/bin/lxfree4java


if [ -d /usr/lib/lxseries4linux ]
then
sudo rm -fr /usr/lib/lxseries4linux
fi

if [ -f /usr/local/bin/lxfreejava ]
then
sudo rm /usr/local/bin/lxfreejava
fi

if [ -f /usr/local/LXFreeJava.jar ]
then
sudo rm -fr /usr/local/LXFreeJava.jar
fi

if [ -f /usr/local/LXFreeForJava.jar ]
then
sudo rm -fr /usr/local/LXFreeForJava.jar
fi

echo "Install script complete."
echo "Use System->Preferences->Main Menu to add an Applications menu item."
echo "The command should be 'lxfree4java'. or 'java -jar /usr/share/claudeheintzdesign-lxseries/LXFreeForJava.jar'"
echo ""
echo "Find the icon for the launcher at usr/share/claudeheintzdesign-lxseries/LXicon.png."
echo ""
echo "press return or enter"
read cs


