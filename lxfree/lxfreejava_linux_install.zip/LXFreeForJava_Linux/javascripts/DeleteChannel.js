var startWith = frame.promptForScriptInput("Delete channel:","1");
if ( startWith != null ) {
	var lights = document.lights();
	var i;
	var cn = parseInt(startWith);
	var lc;
	
	for ( i=0; i< lights.size(); i++ ) {
		var light = lights.elementAt(i);
		lc = parseInt(light.infoForKey("chan"));
		if ( lc >= cn ) {
			light.setInfoForKey(lc-1, "chan");
		}
	}
	
	document.view().repaint();
}