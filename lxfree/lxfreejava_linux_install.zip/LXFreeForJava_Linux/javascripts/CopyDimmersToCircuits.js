var lights = document.lights();
var i;
var lc;

for ( i=0; i< lights.size(); i++ ) {
	var light = lights.elementAt(i);
	lc = parseInt(light.infoForKey("dim"));
	light.setInfoForKey(lc, "cir");
}

document.view().repaint();
