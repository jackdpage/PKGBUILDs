var lights = document.shapes();
var i;
var ct = 0;
for ( i=0; i<lights.size(); i++ ) {
	var shape = lights.elementAt(i);
	if ( shape.isNotEmptyObject() ) {
		shape.selectByScript(false);
	} else {
		shape.selectByScript(true);
		ct++;
	}
}

if ( ct > 0 ) {
	document.view().repaint();
}

frame.alertForScript(ct + " empty objects selected.");

