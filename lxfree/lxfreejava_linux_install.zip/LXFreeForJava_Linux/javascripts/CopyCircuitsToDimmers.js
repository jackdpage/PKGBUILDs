var lights = document.lights();
var i;
var lc;

for ( i=0; i< lights.size(); i++ ) {
	var light = lights.elementAt(i);
	lc = parseInt(light.infoForKey("cir"));
	light.setInfoForKey(lc, "dim");
}

document.view().repaint();
