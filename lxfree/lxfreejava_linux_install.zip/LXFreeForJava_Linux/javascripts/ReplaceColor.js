var searchColor = frame.promptForScriptInput("Choose color:","");
if ( searchColor != null ) {
	var replaceWith = frame.promptForScriptInput("Replace with:","");
	if ( replaceWith != null ) {
		var lights = document.lights();
		var i;
		var ct = 0;
		for ( i=0; i<lights.size(); i++ ) {
			var light = lights.elementAt(i);
			if ( light.infoForKey("color").equals(searchColor) ) {
				light.setInfoForKey(replaceWith, "color");
				ct++;
			}
		}
		frame.alertForScript(ct + " lights' color replaced.");
		if ( ct > 0 ) {
			document.view().repaint();
		}
	}
}