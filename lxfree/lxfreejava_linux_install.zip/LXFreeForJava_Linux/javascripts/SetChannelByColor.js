var searchColor = frame.promptForScriptInput("Choose color:","");
if ( searchColor != null ) {
	var startWith = frame.promptForScriptInput("Start with channel:","1");
	if ( startWith != null ) {
		var lights = document.lights();
		var i;
		var cn = parseInt(startWith);
		
		for ( i=0; i< lights.size(); i++ ) {
			var light = lights.elementAt(i);
			if ( light.infoForKey("color").equals(searchColor) ) {
				light.setInfoForKey(cn, "chan");
				light.addInfoTextFieldForKey("chan");
				cn = cn + 1;
			}
		}

		document.view().repaint();
	}
}