# Copyright 2016 Jack Page

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import itertools
import re
from uuid import uuid4
import xml.etree.ElementTree as ET

from . import XMLNS


def remove_namespace(s):
    '''Remove the namespace prefix from a string.

    ElementTree tags with namespaces are formatted as {ns}tag. 
    Remove the {ns} substring.

    Args:
        s: string to remove the namespace from.
    '''
    regex = re.compile('{.*}')
    return regex.sub('', s)


def boolify(s):
    '''Manage boolean string equivalents.'''

    true_equivs = ['true', 't', 'yes', 'y', 'on', 1, True]
    false_equivs = ['false', 'f', 'no', 'n', 'off', 0, False]

    if s.lower() in true_equivs:
        return True
    elif s.lower() in false_equivs:
        return False
    else:
        return None


class Document:
    '''The XPX document containing all data.

    The Document contains all the information stored in the XPX 
    file and also manages the loading of such files from either 
    file objects or strings.

    Attributes:
        fixtures (list): a list of Fixture objects that exist in the 
                         file.
        registries (list): a list of Registry objects that exist in 
                           the file.
        metadata (list): a list of Metadata objects that exist in 
                         the file.
        scenes (list): a list of Scene objects that exist in the 
                       file.
    '''
    def __init__(self, fp=None, s=None):
        self.fixtures = []
        self.registries = []
        self.metadata = []
        self.cues = []
        self.scenes = []
        self.chases = []
        self.cue_actions = []
        self.cue_locations = []
        if fp:
            self.load(fp)
        elif s:
            self.loads(s)
        else:
            self._tree = None

    def load(self, fp):
        '''Load XPX document from file object.

        Args:
            fp: read-supporting file-like object containing an XPX 
                document.
        '''
        self._tree = ET.parse(fp)
        self._root = self._tree.getroot()
        self._generate_objects()
        self.load_location = fp

    def loads(self, s):
        '''Load XPX document from string.

        Args:
            s: string containing an XPX document.
        '''
        self._tree = ET.fromstring(s)
        self._root = self._tree.getroot()
        self._generate_objects()

    def write(self, fp):
        '''Write the XML tree to a file.

        Update the XML tree based on the object instances, then 
        write this tree to the specified file.
        '''
        self._generate_xml()
        self._tree.write(fp, encoding='utf-8')

    def dump(self):
        '''Dump the contents of the tree to STDOUT.

        Update the XML tree then write the updated tree to STDOUT. 
        For debugging only.
        '''
        self._generate_xml()
        ET.dump(self._tree)

    def get_xelement(self, uuid):
        '''Get an XML element from the tree by UUID.'''
        return self._root.find('.//*[@uuid=\''+uuid+'\']')

    def _generate_objects(self):
        self.fixtures = [Fixture(element=element) for element in 
                         self._root.findall('xpx:fixture', XMLNS)]
        self.registries = [Registry(element=element) for element in 
                           self._root.findall('xpx:registry', XMLNS)]
        self.metadata = [Metadata(element=element) for element in 
                         self._root.findall('xpx:meta', XMLNS)]
        self.scenes = [Scene(element=element) for element in 
                       self._root.findall('xpx:scene', XMLNS)]
        self.chases = [Chase(element=element) for element in 
                       self._root.findall('xpx:chase', XMLNS)]
        self.cues = [Cue(element=element) for element in 
                     self._root.findall('xpx:cue', XMLNS)]

    def _generate_xml(self):
        root_attrs = {'xmlns': 'http://os.pwrg.uk/xmlns/xpx',
                      'version' : '1.0'}
        self._root = ET.Element('plot', attrib=root_attrs) 
        for xpx_object in itertools.chain(self.fixtures, self.registries, 
                                          self.metadata, self.scenes, 
                                          self.chases, self.cues):
            self._root.append(xpx_object.getx())
        self._tree = ET.ElementTree(element=self._root)

    # General object manipulation methods

    def get_object_by_uuid(self, uuid):
        # Check top-level XPX objects
        for xpx_object in itertools.chain(self.fixtures, self.registries,
                                          self.metadata, self.scenes,
                                          self.chases, self.cues):
            if xpx_object.uuid == uuid:
                return xpx_object
        # If that fails, begin to check secondary level objects 
        # i.e. functions
        for fixture in self.fixtures:
            for function in fixture.functions:
                if function.uuid == uuid:
                    return function

    def get_fixture_data_values(self, data_name):
        '''Find the values of fixture data for a certain tag.

        Return a list of every value used in all fixtures for a 
        certain data tag. For example, given the tag gel, return a 
        list of all gels used in the XPX file.

        Args:
            data_name (str): the data to search for.

        Returns:
            A list of strings of the found data (with no duplicates).
        '''
        values = []
        for fixture in self.fixtures:
            if data_name in fixture.data:
                values.append(fixture.data[data_name])
        values = list(set(values))
        return sorted(values)

    def get_fixtures_for_dimmer(self, dimmer):
        '''Find the fixtures controlled by a dimmer fixture.

        Given a fixture which behaves as a dimmer, search 
        through the fixture lists for fixtures which are contrelled 
        by the dimmer.

        Args:
            dimmer (Fixture): dimmer to search for children of.

        Returns:
            A list of Fixture objects which are controlled by the 
            dimmer.
        '''
        if 'isDimmer' not in dimmer.data:
            return []
        if boolify(dimmer.data['isDimmer']) != True:
            return []
        controlled = []
        dimmer_channels = [func.uuid for func in dimmer.functions]
        for fixture in self.fixtures:
            if 'controlDimmer' in fixture.data:
                if fixture.data['controlDimmer'] in dimmer_channels:
                    controlled.append(fixture)
        return controlled

    def get_fixtures_for_dimmer_function(self, function):
        '''Find fixtures controlled by a specific dimmer channel.

        Given a function which is a member of a dimmer, search 
        through the fixture lists for fixtures which are controlled 
        by that channel.

        Args:
             function (DMXFunction): the dimmer function to search.

        Returns:
            A list of Fixture objects which are controlled by the 
            function.
        '''
        controlled = []
        # Test if this function belongs to a dimmer
        dimmer = self.get_fixture_for_function(function)
        if 'isDimmer' in dimmer.data:
            if boolify(dimmer.data['isDimmer']):
                for fixture in self.fixtures:
                    if 'controlDimmer' in fixture.data:
                        if fixture.data['controlDimmer'] == function.uuid:
                            controlled.append(fixture)
        return controlled

    def get_fixture_for_function(self, function):
        '''Find the fixture which contains a given function.

        Search through the document's fixtures to find one which 
        contains the given function.

        Args:
            function (DMXFunction): the function which the fixture 
                                    makes use of.

        Returns:
            A Fixture object which contains this function.
        '''
        for fixture in self.fixtures:
            for func in fixture.functions:
                if func.uuid == function.uuid:
                    return fixture

    def get_channels_for_function(self, function):
        '''Find the channels which control a function.'''
        channels = []
        for registry in self.registries:
            for channel in registry.channels:
                if channel.function.uuid == function.uuid:
                    channels.append(channel)
        return channels

    def get_registry_for_channel(self, channel):
        '''Return the parent registry of a channel.'''
        for registry in self.registries:
            if channel in registry.channels:
                return registry


class XPXReference:
    '''A reference to an XPX object (by UUID).'''
    def __init__(self, uuid):
        self.uuid = uuid

    def get_referenced_object(self, document):
        return document.get_object_by_uuid(self.uuid)


class XPXObject:
    '''Common initialisation for all objects.'''
    def __init__(self, element=None, **kwargs):
        if element is None:
        # Create new element if none is given
            self._factory(kwargs)
        else:
        # Otherwise load information from XML
            self._loadx(element)
            # If the UUID loaded was a placeholder, replace it with a real one
            try:
                if self.uuid == '%UUID%':
                    self.uuid = str(uuid4())
            except AttributeError:
                pass

    # The following three functions must be overrided
    def _factory(self, kwargs):
        '''Create a new instance from keyword arguments.'''
        pass

    def _loadx(self, element):
        '''Create a new instance from an XML element.'''
        pass

    def getx(self):
        '''Create a new XML object from the instance.'''
        pass


class DMXFunction(XPXObject):
    '''The function of a DMX channel on a fixture.

    A DMXFunction describes what effect a DMX channel has on a 
    fixture. It is split into function fragments (DMXFunctionRange), 
    which each are only valid for a specified range of DMX values.
    
    Attributes:
        uuid (str): the UUID of the function.
        name (str): the name of the function.
        type (str): the action this function has on the fixture.
        ranges (list): a list of DMXFunctionRange objects that 
                       describe the effects of this function on 
                       the fixture.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.type = kwargs['type']
        self.ranges = kwargs['ranges']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.type = element.find('xpx:type', XMLNS).text
        self.ranges = []
        for func_range in element.findall('xpx:range', XMLNS):
            self.ranges.append(DMXFunctionRange(element=func_range))

    def getx(self):
        element = ET.Element('function')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        type_element = ET.SubElement(element, 'type')
        type_element.text = self.type
        for func_range in self.ranges:
            element.append(func_range.getx())
        return element


class DMXFunctionRange(XPXObject):
    '''A component of a DMX function.

    A DMXFunctionRange is one component of a DMX function that 
    describes behaviour for a certain range of DMX values. This 
    means that a single channel can have multiple descrete 
    functions dependent on the DMX value.

    Attributes:
        range (tuple): the range of DMX values for which this 
                       function fragment is operative (inclusive).
        name (str): the name of the function fragment.
        type (str): the behaviour of the range as the DMX value is 
                    changed.
        action (str): the type of change this function has on 
                      the fixture.
    '''
    def _factory(self, kwargs):
        self.range = kwargs['func_range']
        self.name = kwargs['name']
        self.type = kwargs['type']
        self.action = kwargs['action']

    def _loadx(self, element):
        self.range = (element.get('start'), element.get('end'))
        self.name = element.find('xpx:rangeName', XMLNS).text
        self.type = element.find('xpx:rangeType', XMLNS).text
        self.action = element.find('xpx:rangeAction', XMLNS).text

    def getx(self):
        element = ET.Element('range')
        element.set('start', self.range[0])
        element.set('end', self.range[1])
        name_element = ET.SubElement(element, 'rangeName')
        name_element.text = self.name
        type_element = ET.SubElement(element, 'rangeType')
        type_element.text = self.type
        action_element = ET.SubElement(element, 'rangeAction')
        action_element.text = self.action
        return element


class Fixture(XPXObject):
    '''A single fixture in the plot.

    Fixtures are fundamental components that represent real-world 
    lighting fixtures/lanterns.

    Attributes:
        uuid (str): the UUID of the fixture.
        name (str): the name of the fixture.
        functions (list): a list of DMXFunction objects that the 
                          fixture uses.
        data (dict): any other key/value data associated with the 
                     fixture.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.functions = kwargs['functions']
        self.data = kwargs['data']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.functions = []
        for func in element.find('xpx:functions', XMLNS):
            self.functions.append(DMXFunction(element=func))
        self.data = {}
        for data in element.find('xpx:data', XMLNS):
            self.data[remove_namespace(data.tag)] = data.text

    def getx(self):
        element = ET.Element('fixture')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        data_element = ET.SubElement(element, 'data')
        for data in self.data:
            data_item_element = ET.SubElement(data_element, data)
            data_item_element.text = self.data[data]
        func_element = ET.SubElement(element, 'functions')
        for func in self.functions:
            func_element.append(func.getx())
        return element

    # Fixture specific methods

    def get_rotation(self):
        '''Calculate the rotation of the fixture.

        Based on the posX, posY, focusX and focusY tags in the 
        fixture's data dictionary, calculate the rotation of the 
        fixture relative to its home position, in radians.

        Returns:
            Fixture rotation in radians.
        '''
        position = (float(self.data['posX']), float(self.data['posY']))
        focus = (float(self.data['focusX']), float(self.data['focusY']))
        return math.atan2(focus[1]-position[1], focus[0]-position[0])


class RegistryChannel(XPXObject):
    '''A single channel in a registry.

    A RegistryChannel represents a single DMX address within a 
    registry. It is bound to a single function.
    
    Attributes:
        address (int): the DMX address which this channel is bound to.
        function (str): the UUID of the function which this channel 
                        controls.
    '''
    def _factory(self, kwargs):
        self.address = int(kwargs['address'])
        self.function = kwargs['function']

    def _loadx(self, element):
        self.address = int(element.get('address'))
        self.function = XPXReference(element.text)

    def getx(self):
        element = ET.Element('channel')
        element.set('address', str(self.address))
        element.text = self.function.uuid
        return element


class Registry(XPXObject):
    '''Manage registry objects.

    Registry objects contain information about the functions of 
    DMX channels in a specific universe.

    Attributes:
        uuid (str): the UUID of the universe.
        name (str): the name of the universe.
        channels (list): a list of RegistryChannel objects describing 
                         the functions of this registry.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.channels = kwargs['channels']
        self.channels.sort(key=lambda c: c.address)

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.channels = []
        for channel in element.find('xpx:channels', XMLNS):
            self.channels.append(RegistryChannel(element=channel))
        self.channels.sort(key=lambda c: c.address)

    def getx(self):
        element = ET.Element('registry')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        chan_element = ET.SubElement(element, 'channels')
        for channel in self.channels:
            chan_element.append(channel.getx())
        return element

    # Registry specific methods

    def get_occupied_addresses(self):
        '''Find the used DMX addresses in a universe.

        Iterate through all the registered channels in a registry 
        to determine which DMX512 addresses are occupied.

        Returns:
            A list of DMX addresses (integers).
        '''
        occupied = [channel.address for channel in self.channels]
        return sorted(occupied)

    def get_available_addresses(self):
        '''Find free DMX addresses in a universe.

        By calling get_occupied_addresses, generate a list of 
        unoccupied addresses in the DMX512 address space.

        Returns:
            A list of DMX addresses (integers).
        '''
        all_dmx = [i for i in range(1, 513)]
        occupied = self.get_occupied_addresses()
        available = [i for i in all_dmx if i not in occupied]
        return sorted(available)

    def get_start_address(self, n):
        '''Find a start address for a certain number of channels.

        Given a number of channels that are required, find in the 
        universe a run of free addresses to which these channels 
        could be patched.

        Args:
            n: the number of consecutive channels required.

        Returns:
            A DMX address (integer).
        '''
        available = self.get_available_addresses()
        for addr in available:
        # Is the required set of addresses a subset of the available 
        # addresses?
            if set([i for i in range(addr, addr+n)]).issubset(available):
                return addr

    def get_channel_by_address(self, address):
        '''Find a channel by its DMX512 address.

        Search through the registry's channel objects to find a 
        channel that corresponds to the given DMX512 address.

        Args:
            address (int): the address to search for.
        '''
        for channel in self.channels:
            if channel.address == address:
                return channel


class Metadata(XPXObject):
    '''Other data in the file which doesn't fall into other categories.

    Metadata is anything else which doesn't fall into one of the 
    other fundamental data types and can take the form 
    foo = bar1, bar2.

    Attributes:
        uuid (str): the UUID of the metadata.
        name (str): the name of the data item.
        value (str): the value of the data item. 
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.value = kwargs['value']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.value = element.find('xpx:value', XMLNS).text

    def getx(self):
        element = ET.Element('meta')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        value_element = ET.SubElement(element, 'value')
        value_element.text = self.value
        return element


class Scene(XPXObject):
    '''A Scene is the state of DMX output at a point in time.

    Scenes are defined by the output of functions in terms of DMX 
    values. Any functions that are not determined by a scene are 
    left unchanged.

    Attributes:
        uuid (str): the UUID of the scene.
        name (str): the name of the scene.
        outputs (list): a list of OutputState objects defining 
                        what the scene looks like.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.outputs = kwargs['outputs']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.outputs = []
        for output in element.find('xpx:outputs', XMLNS):
            self.outputs.append(OutputState(element=output))

    def getx(self):
        element = ET.Element('scene')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        output_element = ET.SubElement(element, 'outputs')
        for output in self.outputs:
            output_element.append(output.getx())
        return element


class OutputState(XPXObject):
    '''The output of a certain function at a moment in time.

    Attributes:
        function (XPXReference): the function being controlled.
        value (int): the DMX output level.
    '''
    def _factory(self, kwargs):
        self.function = kwargs['function']
        self.value = int(kwargs['value'])

    def _loadx(self, element):
        function = element.find('xpx:function', XMLNS)
        self.function = XPXReference(element.text)
        self.value = int(element.get('value'))

    def getx(self):
        element = ET.Element('output')
        element.set('value', str(self.value))
        element.text = self.function.uuid
        return element


class Chase(XPXObject):
    '''A sequence of scenes.

    A chase contains two or more scenes that are fired in sequence. 
    It also contains information about fade times and dwell time.

    Attributes:
        uuid (str): the UUID of the chase.
        name (str): the name of the chase.
        steps (list): a list of the steps in the chase.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.scenes = kwargs['steps']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.steps = []
        for step in element.find('xpx:steps', XMLNS):
            self.steps.append(ChaseStep(element=step))

    def getx(self):
        element = ET.Element('chase')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        steps_element = ET.SubElement(element, 'steps')
        for step in self.steps:
            steps_element.append(step.getx())
        return element

    # Chase specific methods

    def get_iteration_period(self):
        '''Calculate the time for one run of the chase.

        Based on fade and dwell times, calculate the time one 
        iteration of the chase takes to complete.

        Returns:
            A float of the time in seconds to complete the chase.
        '''
        time = float(0)
        for i, step in enumerate(self.steps):
            time += step.fade[1]
            # If we are dealing with the last step in the chase, compare 
            # its fade down time with the fade up time of the first step.
            if i+1 == len(self.steps):
                time += max([step.fade[2], self.steps[0].fade[0]])
            # If this is any other step, just compare with the next step in 
            # the chase.
            else:
                time += max([step.fade[2], self.steps[i+1].fade[0]])
        return time


class ChaseStep(XPXObject):
    '''A single step in a chase sequence.

    A step contains both scene information and also information 
    about how to transition between steps.

    Attributes:
        scene (Scene): the scene that is displayed
        fade (tuple): how long the scene is displayed for and the 
                      transition into and out of it in the form 
                      (fade_up, dwell, fade_down).
    '''
    def _factory(self, kwargs):
        self.scene = kwargs['scene']
        self.fade = kwargs['fade']

    def _loadx(self, element):
        self.fade = (float(element.find('xpx:fadeUp', XMLNS).text),
                     float(element.find('xpx:dwell', XMLNS).text),
                     float(element.find('xpx:fadeDown', XMLNS).text))
        self.scene = XPXReference(element.find('xpx:scene', XMLNS).text)

    def getx(self):
        element = ET.Element('step')
        scene_element = ET.SubElement(element, 'scene')
        scene_element.text = self.scene.uuid
        fdup_element = ET.SubElement(element, 'fadeUp')
        fdup_element.text = str(self.fade[0])
        dwell_element = ET.SubElement(element, 'dwell')
        dwell_element.text = str(self.fade[1])
        fddown_element = ET.SubElement(element, 'fadeDown')
        fddown_element.text = str(self.fade[2])
        return element


class Cue(XPXObject):
    '''A point in time at which something happens.

    A cue describes a point in time, either in realtime or relative 
    to a script, at which some predefined action, such as a 
    lighting state change, occurs. Each cue is a single binding 
    between a location and an action, so if multiple actions happen 
    at a single location, multiple cue instances need to exist.

    Attributes:
        name (str): the displayed name of the cue.
        description (str): a human-readable description of the 
                           location and action of the cue.
        location (CueLocation): the point in absolute or relative 
                                time at which the cue's action 
                                takes place.
        action (CueAction): the action that takes place at the 
                            specified time.
    '''
    def _factory(self, kwargs):
        self.uuid = str(uuid4())
        self.name = kwargs['name']
        self.description = kwargs['description']
        self.location = kwargs['location']
        self.action = kwargs['action']

    def _loadx(self, element):
        self.uuid = element.get('uuid')
        self.name = element.find('xpx:name', XMLNS).text
        self.description = element.find('xpx:description', XMLNS).text
        self.location = CueLocation(element=element.find('xpx:location', XMLNS))
        self.action = CueAction(element=element.find('xpx:action', XMLNS))

    def getx(self):
        element = ET.Element('cue')
        element.set('uuid', self.uuid)
        name_element = ET.SubElement(element, 'name')
        name_element.text = self.name
        desc_element = ET.SubElement(element, 'description')
        desc_element.text = self.description
        element.append(self.location.getx())
        element.append(self.action.getx())
        return element


class CueLocation(XPXObject):
    '''A point in time at which a cue occurs.

    Cue locations can either be absolute, i.e. a single point in 
    realtime, given by an ISO-8601 compliant time string, or 
    relative, i.e. based on a location in a script or a visual or 
    spoken cue.
    '''
    def _factory(self, kwargs):
        self.type = kwargs['type']
        self.event = kwargs['event']

    def _loadx(self, element):
        self.type = element.get('type')
        self.event = element.find('xpx:event', XMLNS).text

    def getx(self):
        element = ET.Element('location')
        element.set('type', self.type)
        event_element = ET.SubElement(element, 'event')
        event_element.text = self.event
        return element


class CueAction(XPXObject):
    '''The event that occurs at a point in time.

    An event that occurs at a point in time as defined by a cue 
    location. Each event needs its own cue binding - a Cue cannot 
    contain multiple events, even if all the events occur at the 
    same cue location.
    '''
    def _factory(self, kwargs):
        self.type = kwargs['type']
        self.fade = kwargs['fade']
        self.output = kwargs['output']

    def _loadx(self, element):
        self.type = element.get('type')
        self.fade = (float(element.find('xpx:fade0', XMLNS).text),
                     float(element.find('xpx:fade1', XMLNS).text),
                     float(element.find('xpx:fade2', XMLNS).text))
        if self.type.lower() == 'lx':
            self.output = XPXReference(element.find('xpx:output', XMLNS).text)
        elif self.type.lower() == 'sx':
            self.output = element.find('xpx:output', XMLNS).text

    def getx(self):
        element = ET.Element('action')
        element.set('type', self.type)
        fd0_element = ET.SubElement(element, 'fade0')
        fd0_element.text = str(self.fade[0])
        fd1_element = ET.SubElement(element, 'fade1')
        fd1_element.text = str(self.fade[1])
        fd2_element = ET.SubElement(element, 'fade2')
        fd2_element.text = str(self.fade[2])
        if self.type == 'lx':
            output_element = ET.SubElement(element, 'output')
            output_element.text = self.output.uuid
        elif self.type == 'sx':
            track_element = ET.SubElement(element, 'track')
            track_element.text = self.track
        return element
